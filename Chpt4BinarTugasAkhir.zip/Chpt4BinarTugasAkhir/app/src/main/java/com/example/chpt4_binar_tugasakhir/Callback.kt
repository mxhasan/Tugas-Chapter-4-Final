package com.example.chpt4_binar_tugasakhir

interface Callback {
    fun kirimStatus(status: String)
}